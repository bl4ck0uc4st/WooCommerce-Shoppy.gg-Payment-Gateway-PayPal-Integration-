<?php
/**
 * Plugin Name: WooCommerce Shoppy Payment Gateway
 * Plugin URI: https://ravangaming.com
 * Description: Accept payments via Shoppy.gg in WooCommerce.
 * Version: 1.1.2
 * Author: ShivbhaktRAVAN
 * Author URI: https://ravangaming.com
 * License: GPL v2 or later
 * WC requires at least: 3.0
 * WC tested up to: 6.0
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('plugins_loaded', 'check_woocommerce_active', 10);

function check_woocommerce_active() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            echo '<div class="error"><p><strong>Shoppy Payment Gateway</strong> requires WooCommerce to be installed and active.</p></div>';
        });
    } else {
        add_filter('woocommerce_payment_gateways', 'add_shoppy_payment_gateway');
    }
}

function add_shoppy_payment_gateway($gateways) {
    $gateways[] = 'WC_Gateway_Shoppy';
    return $gateways;
}

add_action('plugins_loaded', 'init_shoppy_payment_gateway');

function init_shoppy_payment_gateway() {
    if (!class_exists('WC_Payment_Gateway')) return;

    class WC_Gateway_Shoppy extends WC_Payment_Gateway {

        public function __construct() {
            $this->id                 = 'shoppy';
            $this->method_title       = __('Shoppy.gg – Pay with PayPal', 'woocommerce');
            $this->method_description = __('Accept payments via Shoppy.gg (PayPal only)', 'woocommerce');
            $this->supports           = array('products');

            $this->init_form_fields();
            $this->init_settings();

            $this->api_key        = $this->get_option('api_key');
            $this->webhook_secret = $this->get_option('webhook_secret');
            $this->return_url     = $this->get_option('return_url');

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title'   => __('Enable/Disable', 'woocommerce'),
                    'type'    => 'checkbox',
                    'label'   => __('Enable Shoppy Payment Gateway', 'woocommerce'),
                    'default' => 'yes'
                ),
                'api_key' => array(
                    'title'       => __('Shoppy API Key', 'woocommerce'),
                    'type'        => 'password',
                    'description' => __('Enter your Shoppy API Key.', 'woocommerce'),
                    'default'     => '',
                ),
                'webhook_secret' => array(
                    'title'       => __('Webhook Secret', 'woocommerce'),
                    'type'        => 'password',
                    'description' => __('Enter your Shoppy webhook secret.', 'woocommerce'),
                    'default'     => '',
                ),
                'return_url' => array(
                    'title'       => __('Return URL', 'woocommerce'),
                    'type'        => 'text',
                    'description' => __('URL where customers will be redirected after payment.', 'woocommerce'),
                    'default'     => home_url('/checkout/order-received'),
                ),
            );
        }

        public function process_payment($order_id) {
            $order = wc_get_order($order_id);
            $amount = $order->get_total();
            $customer_email = $order->get_billing_email();
            $gateway = ["PayPal"];

            $api_body = array(
                'title'   => 'Order #' . $order_id,
                'value'   => $amount,
                'email'   => $customer_email,
                'gateways' => $gateway,
                'custom_fields' => [
                    ["title" => "order_id", "value" => $order_id]
                ]
            );

            $response = wp_remote_post("https://shoppy.gg/api/v2/pay", array(
                'method'  => 'POST',
                'headers' => array(
                    'Authorization' => $this->api_key,
                    'Content-Type'  => 'application/json',
                    'User-Agent'    => 'ShoppyWooCommerce',
                ),
                'body'    => json_encode($api_body),
                'timeout' => 30,
            ));

            if (is_wp_error($response)) {
                wc_add_notice(__('Shoppy payment failed: ' . $response->get_error_message(), 'woocommerce'), 'error');
                return array('result' => 'failure');
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);

            if (!empty($response_body['url'])) {
                return [
                    'result'   => 'success',
                    'redirect' => esc_url($response_body['url']),
                ];
            } else {
                wc_add_notice(__('Shoppy payment failed: ' . ($response_body['message'] ?? 'Unknown error'), 'woocommerce'), 'error');
                return array('result' => 'failure');
            }
        }
    }
}

add_filter('woocommerce_gateway_icon', 'shoppy_payment_icon', 10, 2);

function shoppy_payment_icon($icon, $id) {
    if ($id === 'shoppy') {
        return '<span style="display:flex;align-items:center;">
            <span style="margin-right:10px;">Pay With PayPal via Secure Shoppy</span>
            <img src="https://ravangaming.com/wp-content/uploads/2025/02/Paypal_2014_logo.png"
            alt="PayPal" style="width:40px;height:auto;"/>
        </span>';
    }
    return $icon;
}

add_action('woocommerce_api_shoppy_webhook', 'handle_shoppy_webhook');

function handle_shoppy_webhook() {
    $shoppy_settings = get_option('woocommerce_shoppy_settings');
    $webhook_secret = $shoppy_settings['webhook_secret'] ?? '';

    $headers = getallheaders();
    $payload = file_get_contents('php://input');
    $signature = hash_hmac('sha512', $payload, $webhook_secret);

    if (!isset($headers['X-Shoppy-Signature']) || !hash_equals($signature, $headers['X-Shoppy-Signature'])) {
        http_response_code(403);
        exit;
    }

    $data = json_decode($payload, true);

    if (!isset($data['event']) || $data['event'] !== 'order:paid') {
        http_response_code(400);
        exit;
    }

    if (!isset($data['data']['custom_fields'][0]['value'])) {
        http_response_code(400);
        exit;
    }

    $order_id = $data['data']['custom_fields'][0]['value'];
    $order = wc_get_order($order_id);

    if (!$order) {
        http_response_code(404);
        exit;
    }

    if ($order->get_status() !== 'processing') {
        $order->payment_complete();
        $order->update_status('processing', __('Payment received via Shoppy.gg – Pay with PayPal', 'woocommerce'));
        WC()->mailer()->get_emails()['WC_Email_Customer_Processing_Order']->trigger($order_id);
        $order->add_order_note('Payment received via Shoppy.gg (PayPal).');
    }

    http_response_code(200);
    exit;
}
?>